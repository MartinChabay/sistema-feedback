package Tp3;
// clase para vincular la base de datos 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class databaseConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/feedback";
	private static final String USER = "root";
	private static final String PASSWORD = "12345";
	private static Connection connection = null;

	public static Connection getConnection() {
		System.out.println("Conectando a la Base de Datos...");
		try {
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("Conexión Exitosa");
		} catch (SQLException e) {
			System.out.println("Conexión Fallida");
			e.printStackTrace();
		}
		return connection;
	}

	public static void disconnect() {
		if (connection != null) {
			try {
				connection.close();
				System.out.println("Desconexión Exitosa");
			} catch (SQLException e) {
				System.out.println("Error al desconectar la base de datos");
				e.printStackTrace();
			}
		}
	}
}
