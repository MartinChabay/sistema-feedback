package Tp3;

//Clase que representa a un cliente del sistema
public class cliente {
 protected String nombre;

 // Constructor que inicializa el nombre del cliente
 public cliente(String nombre) {
     this.nombre = nombre;
 }

 // Método para obtener el nombre del cliente
 public String getNombre() {
     return nombre;
 }
}


