package Tp3;

// Clase feedback asociada con la base de datos
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class feedbackDao {

	// Método para insertar un feedback
	public void insertFeedback(feedback feedback) {
		String sql = "INSERT INTO feedbacks (id_cliente, id_producto, atencion_cliente, calidad_materiales, funcionamiento, promedio, comentario) VALUES (?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			pstmt.setInt(1, feedback.getClienteId());
			pstmt.setInt(2, feedback.getProductoId());
			pstmt.setInt(3, feedback.getAtencionCliente());
			pstmt.setInt(4, feedback.getCalidadMateriales());
			pstmt.setInt(5, feedback.getFuncionamiento());
			pstmt.setDouble(6, feedback.getPromedio());
			pstmt.setString(7, feedback.getComentario());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Feedback insertado correctamente.");
				try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						feedback.setId(generatedKeys.getInt(1));
					} else {
						System.out.println("No se pudo obtener el ID del feedback insertado.");
					}
				}
			} else {
				System.out.println("Error al insertar el feedback.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para leer un feedback por ID
	public feedback getFeedbackById(int id) {
		String sql = "SELECT * FROM feedbacks WHERE id_feedback = ?";
		feedback feedback = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				feedback = new feedback(rs.getInt("id_feedback"), rs.getInt("id_cliente"), rs.getInt("id_producto"),
						rs.getInt("atencion_cliente"), rs.getInt("calidad_materiales"), rs.getInt("funcionamiento"),
						rs.getDouble("promedio"), rs.getString("comentario"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return feedback;
	}

	// Método para actualizar un feedback
	public void updateFeedback(feedback feedback) {
		String sql = "UPDATE feedbacks SET atencion_cliente = ?, calidad_materiales = ?, funcionamiento = ?, promedio = ?, comentario = ? WHERE id_feedback = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, feedback.getAtencionCliente());
			pstmt.setInt(2, feedback.getCalidadMateriales());
			pstmt.setInt(3, feedback.getFuncionamiento());
			pstmt.setDouble(4, feedback.getPromedio());
			pstmt.setString(5, feedback.getComentario());
			pstmt.setInt(6, feedback.getId());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Feedback actualizado correctamente.");
			} else {
				System.out.println("Error al actualizar el feedback.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para eliminar un feedback por ID
	public void deleteFeedback(int id) {
		String sql = "DELETE FROM feedbacks WHERE id_feedback = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Feedback eliminado correctamente.");
			} else {
				System.out.println("Error al eliminar el feedback.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
