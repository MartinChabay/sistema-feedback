package Tp3;

//Clase que representa un producto
public class producto {
 private String nombre;

 // Constructor que inicializa el nombre del producto
 public producto(String nombre) {
     this.nombre = nombre;
 }

 // Método para obtener el nombre del producto
 public String getNombre() {
     return nombre;
 }
}