package Tp3;

//Clase principal que inicia el sistema de feedback
public class main {
 public static void main(String[] args) {
     sistemaFeedback sistema = new sistemaFeedback();
     sistema.iniciar();
 }
}