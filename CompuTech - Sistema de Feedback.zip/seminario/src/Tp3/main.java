package Tp3;

//Clase principal que inicia el sistema de feedback
public class main {
	public static void main(String[] args) {
		// Conectar a la base de datos
		if (databaseConnection.getConnection() != null) {
			sistemaFeedback sistema = new sistemaFeedback();
			sistema.iniciar();

			// Salir del sistema y desconectar la base de datos
			sistema.salir();
		} else {
			System.out.println("Error: No se pudo establecer conexión con la base de datos. Saliendo del sistema.");
		}
	}
}
