package Tp3;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class sistemaFeedback {
    // Lista para almacenar los informes de feedback
    private ArrayList<feedback> feedbacks = new ArrayList<>();
    
    // Scanner para leer la entrada del usuario
    private Scanner scanner = new Scanner(System.in);
    
    // Variables para almacenar el cliente y el empleado actuales
    private cliente clienteActual;
    private empleado empleadoActual;
    
    // Formateador de decimales para mostrar los números con un solo decimal
    private DecimalFormat df = new DecimalFormat("#.#", DecimalFormatSymbols.getInstance(Locale.ENGLISH));

    // Método principal para iniciar el sistema
    public void iniciar() {
        while (true) {
            System.out.println("\n¿Eres un Cliente o un Empleado?");
            System.out.println("1. Cliente");
            System.out.println("2. Empleado");
            System.out.println("3. Salir del sistema\n");
            int opcion = 0;
            try {
                // Leera opción del usuario
                opcion = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un caracter valido.");
                scanner.nextLine();
                continue;
            }
            scanner.nextLine();
            
            // Determinara acción basada en la opción del usuario
            switch(opcion) {
                case 1:
                    String nombreCliente = obtenerNombre("Cliente");
                    clienteActual = new cliente(nombreCliente);  // Creara un nuevo cliente
                    menuCliente();  // Mostrara el menú del cliente
                    break;
                case 2:
                    String nombreEmpleado = obtenerNombre("Empleado");
                    empleadoActual = new empleado(nombreEmpleado);  // Creara un nuevo empleado
                    menuEmpleado();  // Mostrara el menú del empleado
                    break;
                case 3:
                    System.out.println("¡Gracias por usar el sistema!");
                    return;  // Saldra del sistema
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    // Método para obtener y validar el nombre
    private String obtenerNombre(String tipoUsuario) {
        String nombre;
        while (true) {
            System.out.println("Ingrese su nombre de Usuario (" + tipoUsuario + "):");
            nombre = scanner.nextLine();
            if (!nombre.trim().isEmpty()) {
                break;
            } else {
                System.out.println("El campo no puede estar vacío. Por favor, ingrese su nombre.");
            }
        }
        return nombre;
    }

    // Menú para los clientes
    private void menuCliente() {
        while (true) {
            System.out.println("\nMenú Cliente:");
            System.out.println("1. Generar Feedback");
            System.out.println("2. Ver Feedbacks");
            System.out.println("3. Salir\n");
            int opcion = 0;
            try {
                opcion = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número de opcion.");
                scanner.nextLine(); 
                continue;
            }
            scanner.nextLine();

            switch(opcion) {
                case 1:
                    generarInforme();
                    break;
                case 2:
                    mostrarInformes();
                    break;
                case 3:
                    System.out.println("¡Gracias por usar el sistema!");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }


    // Menú para los empleados
    private void menuEmpleado() {
        while (true) {
            System.out.println("\nMenú Empleado:");
            System.out.println("1. Ver Feedbacks");
            System.out.println("2. Responder Feedback");
            System.out.println("3. Ver Respuestas");
            System.out.println("4. Eliminar Feedback");
            System.out.println("5. Salir\n");
            int opcion = 0;
            try {
                opcion = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("opcion inválida. Por favor, ingrese una opcion valida.");
                scanner.nextLine();  
                continue;
            }
            scanner.nextLine(); 

            switch(opcion) {
                case 1:
                    mostrarInformesConNombres();
                    break;
                case 2:
                    System.out.println("Ingrese el ID del feedback a responder:");
                    int id = obtenerId();
                    if (existeInforme(id)) {
                        System.out.println("Ingrese la respuesta:");
                        String respuesta = scanner.nextLine();
                        responderInforme(id, respuesta, empleadoActual.getNombre());
                    } else {
                        System.out.println("No se encontraron feedbacks con ese ID :( .");
                    }
                    break;
                case 3:
                    mostrarRespuestas();
                    break;
                case 4:
                    System.out.println("Ingrese el ID del feedback a eliminar:");
                    int idEliminar = obtenerId();
                    eliminarInforme(idEliminar);
                    break;
                case 5:
                    System.out.println("¡Gracias por usar el sistema!");
                    return;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    // Método para generar un nuevo Feedback
    public void generarInforme() {
        System.out.println("Nombre del Producto:");
        String producto = scanner.nextLine();
        int atencionCliente = obtenerValoracion("Atención al cliente");
        int calidadMateriales = obtenerValoracion("Calidad de los materiales");
        int funcionamiento = obtenerValoracion("Funcionamiento");

        // Calculara el promedio de las valoraciones y lo formateara a un solo decimal
        double promedio = (atencionCliente + calidadMateriales + funcionamiento) / 3.0;
        String promedioFormateado = df.format(promedio);
        feedback feedback = new feedback(producto, clienteActual.getNombre(), 
        atencionCliente, calidadMateriales, funcionamiento, Double.parseDouble(promedioFormateado));
        feedbacks.add(feedback);  // Añadira el Feedback a la lista de informes
        System.out.println("¡Informe generado con éxito!");
    }

    // Método para obtener y validar las valoraciones del cliente

    private int obtenerValoracion(String criterio) {
        int valoracion;
        while (true) {
            System.out.println(criterio + " (1-5 estrellas):");
            try {
                valoracion = scanner.nextInt();
                scanner.nextLine();
                if (valoracion >= 1 && valoracion <= 5) {
                    break;
                } else {
                    System.out.println("Número inválido. Solo se puede del 1 al 5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número del 1 al 5.");
                scanner.nextLine(); 
            }
        }
        return valoracion;
    }

    // Método para mostrar todos los feedbacks
    public void mostrarInformes() {
        for (feedback feedback : feedbacks) {
            System.out.println(feedback.mostrar());
        }
    }

    // Método para mostrar todos los feedbacks con los nombres de los clientes
    public void mostrarInformesConNombres() {
        if (feedbacks.isEmpty()) {
            System.out.println("No se encuentran feedback disponibles.");
        } else {
            for (feedback feedback : feedbacks) {
                System.out.println(feedback.mostrar());
            }
        }
    }


    // Método para responder a un feedback
    public void responderInforme(int id, String respuesta, String nombreEmpleado) {
        if (feedbacks.isEmpty()) {
            System.out.println("No se encuentran feedback disponibles.");
            return;
        }

        boolean encontrado = false;
        for (feedback feedback : feedbacks) {
            if (feedback.getId() == id) {
                feedback.setRespuesta(new respuesta(respuesta));
                System.out.println("¡Feedback respondido con éxito!");
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontre feedback con ese ID.");
        }
    }


    // Método para eliminar un Feedback
    public void eliminarInforme(int id) {
        if (feedbacks.isEmpty()) {
            System.out.println("No se encuentran feedback disponibles.");
            return;
        }

        boolean eliminado = feedbacks.removeIf(feedback -> feedback.getId() == id);
        if (eliminado) {
            System.out.println("¡Feedback eliminado con éxito!");
        } else {
            System.out.println("No se encontre feedback con ese ID.");
        }
    }


    // Método para mostrar todas las respuestas a los feedbacks
    public void mostrarRespuestas() {
        if (feedbacks.isEmpty()) {
            System.out.println("No se encuentran feedback disponibles.");
            return;
        }

        boolean hayRespuestas = false;
        for (feedback feedback : feedbacks) {
            if (feedback.getRespuesta() != null) {
                System.out.println("ID: " + feedback.getId() + "\nRespuesta: " + feedback.getRespuesta().getTexto() + "\nRespondido por: " + empleadoActual.getNombre());
                hayRespuestas = true;
            }
        }
        if (!hayRespuestas) {
            System.out.println("No hay respuestas disponibles.");
        }
    }



    // Método para obtener y validar el ID del Feedback
    private int obtenerId() {
        int id = 0;
        while (true) {
            try {
                id = scanner.nextInt();
                scanner.nextLine();
                break;
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número valido.");
                scanner.nextLine();  
            }
        }
        return id;
    }

    // Método para verificar si un Feedback existe
    private boolean existeInforme(int id) {
        for (feedback feedback : feedbacks) {
            if (feedback.getId() == id) {
                return true;
            }
        }
        return false;
    }
}


