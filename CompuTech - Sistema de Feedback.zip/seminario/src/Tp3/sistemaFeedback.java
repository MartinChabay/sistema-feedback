package Tp3;

// clase principal que maneja el sistema de feedback
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class sistemaFeedback {
	// Lista para almacenar los informes de feedback
	private ArrayList<feedback> feedbacks = new ArrayList<>();

	// Scanner para leer la entrada del usuario
	private Scanner scanner = new Scanner(System.in);

	// Variables para almacenar el cliente y el empleado actuales
	private cliente clienteActual;
	private empleado empleadoActual;

	// Formateador de decimales para mostrar los números con un solo decimal
	private DecimalFormat df = new DecimalFormat("#.#", DecimalFormatSymbols.getInstance(Locale.ENGLISH));

	// Método principal para iniciar el sistema
	public void iniciar() {
		while (true) {
			System.out.println("\n¿Eres un Cliente o un Empleado?");
			System.out.println("1. Cliente");
			System.out.println("2. Empleado");
			System.out.println("3. Salir del sistema\n");
			int opcion = 0;
			try {
				// Leer opción del usuario
				opcion = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Entrada inválida. Por favor, ingrese un caracter valido.");
				scanner.nextLine();
				continue;
			}
			scanner.nextLine();

			// Determinar acción basada en la opción del usuario
			switch (opcion) {
			case 1:
				String nombreCliente = obtenerNombre("Cliente");
				clienteActual = new cliente(nombreCliente); // Crear un nuevo cliente
				menuCliente(); // Mostrar el menú del cliente
				break;
			case 2:
				String nombreEmpleado = obtenerNombre("Empleado");
				empleadoActual = new empleado(nombreEmpleado); // Crear un nuevo empleado
				menuEmpleado(); // Mostrar el menú del empleado
				break;
			case 3:
				System.out.println("¡Gracias por usar el sistema!");
				salir();
				return; // Salir del sistema
			default:
				System.out.println("Opción no válida.");
			}
		}
	}

	// Método para obtener y validar el nombre
	private String obtenerNombre(String tipoUsuario) {
		String nombre;
		while (true) {
			System.out.println("Ingrese su nombre de Usuario (" + tipoUsuario + "):");
			nombre = scanner.nextLine();
			if (!nombre.trim().isEmpty()) {
				break;
			} else {
				System.out.println("El campo no puede estar vacío. Por favor, ingrese su nombre.");
			}
		}
		return nombre;
	}

	// Menú para los clientes
	private void menuCliente() {
		while (true) {
			System.out.println("\nMenú Cliente:");
			System.out.println("1. Generar Feedback");
			System.out.println("2. Ver Feedbacks");
			System.out.println("3. Salir\n");
			int opcion = 0;
			try {
				opcion = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Entrada inválida. Por favor, ingrese un número de opción.");
				scanner.nextLine();
				continue;
			}
			scanner.nextLine();

			switch (opcion) {
			case 1:
				generarInforme();
				break;
			case 2:
				mostrarInformes();
				break;
			case 3:
				System.out.println("¡Gracias por usar el sistema!");
				salir();
				return;
			default:
				System.out.println("Opción no válida.");
			}
		}
	}

	// Menú para los empleados
	private void menuEmpleado() {
		while (true) {
			System.out.println("\nMenú Empleado:");
			System.out.println("1. Ver Feedbacks");
			System.out.println("2. Responder Feedback");
			System.out.println("3. Ver Respuestas");
			System.out.println("4. Eliminar Feedback");
			System.out.println("5. Salir\n");
			int opcion = 0;
			try {
				opcion = scanner.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Opción inválida. Por favor, ingrese una opción válida.");
				scanner.nextLine();
				continue;
			}
			scanner.nextLine();

			switch (opcion) {
			case 1:
				mostrarInformesConNombres();
				break;
			case 2:
				System.out.println("Ingrese el ID del feedback a responder:");
				int id = obtenerId();
				if (existeInforme(id)) {
					System.out.println("Ingrese la respuesta:");
					String respuesta = scanner.nextLine();
					responderInforme(id, respuesta, empleadoActual.getNombre());
				} else {
					System.out.println("No se encontraron feedbacks con ese ID.");
				}
				break;
			case 3:
				mostrarRespuestas();
				break;
			case 4:
				System.out.println("Ingrese el ID del feedback a eliminar:");
				int idEliminar = obtenerId();
				eliminarInforme(idEliminar);
				break;
			case 5:
				System.out.println("¡Gracias por usar el sistema!");
				salir();
				return;
			default:
				System.out.println("Opción no válida.");
			}
		}
	}

	// Método para mostrar todos los feedbacks
	public void mostrarInformes() {
		if (feedbacks.isEmpty()) {
			System.out.println("No se encuentran feedback disponibles.");
		} else {
			for (feedback feedback : feedbacks) {
				System.out.println(feedback.mostrar());
			}
		}
	}

	// Método para mostrar todos los feedbacks con los nombres de los clientes
	public void mostrarInformesConNombres() {
		if (feedbacks.isEmpty()) {
			System.out.println("No se encuentran feedback disponibles.");
		} else {
			clienteDao clienteDAO = new clienteDao();
			for (feedback feedback : feedbacks) {
				cliente cliente = clienteDAO.getClienteById(feedback.getClienteId());
				String nombreCliente = cliente != null ? cliente.getNombre() : "Desconocido";
				System.out.println("Nombre del Cliente: " + nombreCliente);
				System.out.println("ID del Cliente: " + feedback.getClienteId());
				System.out.println("ID del Feedback: " + feedback.getId());
				System.out.println(feedback.mostrar());
			}
		}
	}

	// Método para obtener y validar el ID del Feedback
	private int obtenerId() {
		int id = 0;
		while (true) {
			try {
				id = scanner.nextInt();
				scanner.nextLine();
				break;
			} catch (InputMismatchException e) {
				System.out.println("Entrada inválida. Por favor, ingrese un número valido.");
				scanner.nextLine();
			}
		}
		return id;
	}

	// Método para verificar si un Feedback existe
	private boolean existeInforme(int id) {
		for (feedback feedback : feedbacks) {
			if (feedback.getId() == id) {
				return true;
			}
		}
		return false;
	}

	// Método para salir del sistema
	public void salir() {
		databaseConnection.disconnect();
		System.out.println("Desconexión Exitosa. Has salido del sistema.");
	}

	// Metodo para generar informes
	public void generarInforme() {
		// Verificar y/o agregar el cliente
		System.out.println("Ingrese su nombre de Usuario (Cliente):");
		String nombreCliente = scanner.nextLine();
		clienteActual = obtenerOAgregarCliente(nombreCliente);

		// Verificar y/o agregar el producto
		System.out.println("Nombre del Producto:");
		String nombreProducto = scanner.nextLine();

		int productoId = obtenerProductoIdPorNombre(nombreProducto);
		if (productoId == -1) {
			System.out.println("Producto no encontrado. ¿Desea agregarlo a la base de datos? (si/no)");
			String respuesta = scanner.nextLine().toLowerCase();
			if (respuesta.equals("si")) {
				System.out.println("Ingrese la descripción del producto:");
				String descripcionProducto = scanner.nextLine();
				producto nuevoProducto = new producto(nombreProducto, descripcionProducto);
				productoDao productoDAO = new productoDao();
				productoDAO.insertProducto(nuevoProducto);
				productoId = nuevoProducto.getId();
				System.out.println("Producto agregado con éxito. ID del producto: " + productoId);
			} else {
				System.out.println("No se puede generar el informe sin un producto válido.");
				return;
			}
		}

		int atencionCliente = obtenerValoracion("Atención al cliente");
		int calidadMateriales = obtenerValoracion("Calidad de los materiales");
		int funcionamiento = obtenerValoracion("Funcionamiento");

		double promedio = (atencionCliente + calidadMateriales + funcionamiento) / 3.0;
		String promedioFormateado = df.format(promedio);

		String comentario = "";
		while (true) {
			System.out.println("Comentarios (máximo 500 caracteres, opcional):");
			comentario = scanner.nextLine();
			if (comentario.length() <= 500) {
				break;
			} else {
				System.out.println(
						"Comentario demasiado largo. Por favor, ingrese un comentario de máximo 500 caracteres.");
			}
		}

		feedback feedback = new feedback(clienteActual.getId(), productoId, atencionCliente, calidadMateriales,
				funcionamiento, Double.parseDouble(promedioFormateado), comentario);
		feedbackDao feedbackDAO = new feedbackDao();
		feedbackDAO.insertFeedback(feedback);
		feedbacks.add(feedback); // Asegúrate de que este feedback se añade correctamente a la lista de feedbacks
		System.out.println("¡Informe generado con éxito!");
	}

	// Método para eliminar un Feedback
	public void eliminarInforme(int id) {
		if (feedbacks.isEmpty()) {
			System.out.println("No se encuentran feedback disponibles.");
			return;
		}

		boolean eliminado = feedbacks.removeIf(feedback -> feedback.getId() == id);
		if (eliminado) {
			System.out.println("¡Feedback eliminado con éxito!");
		} else {
			System.out.println("No se encontró feedback con ese ID.");
		}
	}

	// Método para mostrar todas las respuestas a los feedbacks
	public void mostrarRespuestas() {
		if (feedbacks.isEmpty()) {
			System.out.println("No se encuentran feedback disponibles.");
			return;
		}

		boolean hayRespuestas = false;
		for (feedback feedback : feedbacks) {
			if (feedback.getRespuesta() != null) {
				System.out.println("ID: " + feedback.getId() + "\nRespuesta: " + feedback.getRespuesta().getTexto()
						+ "\nRespondido por: " + empleadoActual.getNombre());
				hayRespuestas = true;
			}
		}
		if (!hayRespuestas) {
			System.out.println("No hay respuestas disponibles.");
		}
	}

	// Método para obtener y validar las valoraciones del cliente
	private int obtenerValoracion(String criterio) {
		int valoracion;
		while (true) {
			System.out.println(criterio + " (1-5 estrellas):");
			try {
				valoracion = scanner.nextInt();
				scanner.nextLine();
				if (valoracion >= 1 && valoracion <= 5) {
					break;
				} else {
					System.out.println("Número inválido. Solo se puede del 1 al 5.");
				}
			} catch (InputMismatchException e) {
				System.out.println("Entrada inválida. Por favor, ingrese un número del 1 al 5.");
				scanner.nextLine();
			}
		}
		return valoracion;
	}

	// Metodo para obtener la id del cliente por su nombre
	private int obtenerClienteIdPorNombre(String nombreCliente) {
		clienteDao clienteDAO = new clienteDao();
		cliente cliente = clienteDAO.getClienteByNombre(nombreCliente);
		if (cliente != null) {
			return cliente.getId();
		} else {
			System.out.println("Cliente no encontrado. ¿Desea agregarlo a la base de datos? (si/no)");
			String respuesta = scanner.nextLine().toLowerCase();
			if (respuesta.equals("si")) {
				cliente nuevoCliente = new cliente(nombreCliente);
				clienteDAO.insertCliente(nuevoCliente);
				return nuevoCliente.getId();
			} else {
				System.out.println("No se puede proceder sin un cliente válido.");
				return -1; // Indica que no se puede proceder
			}
		}
	}

// Metodo para obtener la id del producto pr su nombre 
	private int obtenerProductoIdPorNombre(String nombreProducto) {
		productoDao productoDAO = new productoDao();
		producto producto = productoDAO.getProductoByNombre(nombreProducto);
		if (producto != null) {
			return producto.getId();
		} else {
			return -1; // Producto no encontrado
		}
	}

	// Metodo para obtenr o agregar clientes
	private cliente obtenerOAgregarCliente(String nombreCliente) {
		clienteDao clienteDAO = new clienteDao();
		cliente clienteExistente = clienteDAO.getClienteByNombre(nombreCliente);
		if (clienteExistente != null) {
			return clienteExistente;
		} else {
			cliente nuevoCliente = new cliente(nombreCliente);
			clienteDAO.insertCliente(nuevoCliente);
			return nuevoCliente;
		}
	}

	// Metodo para obtenr o agregar empleados
	private empleado obtenerOAgregarEmpleado(String nombreEmpleado) {
		empleadoDao empleadoDAO = new empleadoDao();
		empleado empleadoExistente = empleadoDAO.getEmpleadoByNombre(nombreEmpleado);
		if (empleadoExistente != null) {
			return empleadoExistente;
		} else {
			empleado nuevoEmpleado = new empleado(nombreEmpleado);
			empleadoDAO.insertEmpleado(nuevoEmpleado);
			return nuevoEmpleado;
		}
	}

	// Metodo para responder los informes
	public void responderInforme(int id, String respuesta, String nombreEmpleado) {
		System.out.println("Ingrese su nombre de Empleado:");
		empleadoActual = obtenerOAgregarEmpleado(nombreEmpleado);

		if (feedbacks.isEmpty()) {
			System.out.println("No se encuentran feedback disponibles.");
			return;
		}

		boolean encontrado = false;
		for (feedback feedback : feedbacks) {
			if (feedback.getId() == id) {
				Timestamp fechaRespuesta = new Timestamp(System.currentTimeMillis());
				respuesta nuevaRespuesta = new respuesta(feedback.getId(), empleadoActual.getId(), respuesta,
						fechaRespuesta);
				respuestaDao respuestaDAO = new respuestaDao();
				respuestaDAO.insertRespuesta(nuevaRespuesta);
				feedback.setRespuesta(nuevaRespuesta);
				System.out.println("¡Feedback respondido con éxito por " + nombreEmpleado + "!");
				encontrado = true;
				break;
			}
		}
		if (!encontrado) {
			System.out.println("No se encontró feedback con ese ID.");
		}
	}

}
