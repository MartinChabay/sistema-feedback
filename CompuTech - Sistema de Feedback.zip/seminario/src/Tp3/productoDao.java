package Tp3;
// Clase producto asociada con la base de datos
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class productoDao {

	// Método para insertar un producto
	public void insertProducto(producto producto) {
		String sql = "INSERT INTO productos (nombre, descripcion) VALUES (?, ?)";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			pstmt.setString(1, producto.getNombre());
			pstmt.setString(2, producto.getDescripcion());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Producto insertado correctamente.");
				try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						producto.setId(generatedKeys.getInt(1));
					} else {
						System.out.println("No se pudo obtener el ID del producto insertado.");
					}
				}
			} else {
				System.out.println("Error al insertar el producto.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para leer un producto por ID
	public producto getProductoById(int id) {
		String sql = "SELECT * FROM productos WHERE id_producto = ?";
		producto producto = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				producto = new producto(rs.getInt("id_producto"), rs.getString("nombre"), rs.getString("descripcion"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return producto;
	}

	// Método para obtener un producto por su nombre
	public producto getProductoByNombre(String nombre) {
		String sql = "SELECT * FROM productos WHERE nombre = ?";
		producto producto = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, nombre);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				producto = new producto(rs.getInt("id_producto"), rs.getString("nombre"), rs.getString("descripcion"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return producto;
	}

	// Método para actualizar un producto
	public void updateProducto(producto producto) {
		String sql = "UPDATE productos SET nombre = ?, descripcion = ? WHERE id_producto = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, producto.getNombre());
			pstmt.setString(2, producto.getDescripcion());
			pstmt.setInt(3, producto.getId());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Producto actualizado correctamente.");
			} else {
				System.out.println("Error al actualizar el producto.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para eliminar un producto por ID
	public void deleteProducto(int id) {
		String sql = "DELETE FROM productos WHERE id_producto = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Producto eliminado correctamente.");
			} else {
				System.out.println("Error al eliminar el producto.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
