package Tp3;
// clase empleado asociada con la base de datos 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class empleadoDao {

	// Método para obtener un empleado por su nombre
	public empleado getEmpleadoByNombre(String nombre) {
		String sql = "SELECT * FROM empleados WHERE nombre = ?";
		empleado empleado = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, nombre);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				empleado = new empleado(rs.getInt("id_empleado"), rs.getString("nombre"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empleado;
	}

	// Método para insertar un empleado
	public void insertEmpleado(empleado empleado) {
		String sql = "INSERT INTO empleados (nombre) VALUES (?)";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			pstmt.setString(1, empleado.getNombre());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Empleado insertado correctamente.");
				try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						empleado.setId(generatedKeys.getInt(1));
					} else {
						System.out.println("No se pudo obtener el ID del empleado insertado.");
					}
				}
			} else {
				System.out.println("Error al insertar el empleado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para leer un empleado por ID
	public empleado getEmpleadoById(int id) {
		String sql = "SELECT * FROM empleados WHERE id_empleado = ?";
		empleado empleado = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				empleado = new empleado(rs.getInt("id_empleado"), rs.getString("nombre"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empleado;
	}

	// Método para actualizar un empleado
	public void updateEmpleado(empleado empleado) {
		String sql = "UPDATE empleados SET nombre = ? WHERE id_empleado = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, empleado.getNombre());
			pstmt.setInt(2, empleado.getId());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Empleado actualizado correctamente.");
			} else {
				System.out.println("Error al actualizar el empleado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para eliminar un empleado por ID
	public void deleteEmpleado(int id) {
		String sql = "DELETE FROM empleados WHERE id_empleado = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Empleado eliminado correctamente.");
			} else {
				System.out.println("Error al eliminar el empleado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
