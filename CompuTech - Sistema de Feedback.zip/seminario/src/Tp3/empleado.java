package Tp3;

public class empleado extends cliente {

    public empleado(String nombre) {
        super(nombre);
    }

    public void verInformes(sistemaFeedback sistema) {
        sistema.mostrarInformesConNombres();
    }

    public void responderInforme(int idInforme, String respuesta, sistemaFeedback sistema) {
        sistema.responderInforme(idInforme, respuesta, this.nombre);  // Enviar los tres parámetros
    }

    public void eliminarInforme(int idInforme, sistemaFeedback sistema) {
        sistema.eliminarInforme(idInforme);
    }
}
