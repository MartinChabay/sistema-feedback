package Tp3;
// Clase de los clientes asociada a la base de datos
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class clienteDao {

	// Método para actualizar un cliente
	public void updateCliente(cliente cliente) {
		String sql = "UPDATE clientes SET nombre = ? WHERE id_cliente = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, cliente.getNombre());
			pstmt.setInt(2, cliente.getId());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Cliente actualizado correctamente.");
			} else {
				System.out.println("Error al actualizar el cliente.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para obtener un cliente por su nombre
	public cliente getClienteByNombre(String nombre) {
		String sql = "SELECT * FROM clientes WHERE nombre = ?";
		cliente cliente = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, nombre);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				cliente = new cliente(rs.getInt("id_cliente"), rs.getString("nombre"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cliente;
	}

	// Método para insertar un cliente
	public void insertCliente(cliente cliente) {
		String sql = "INSERT INTO clientes (nombre) VALUES (?)";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			pstmt.setString(1, cliente.getNombre());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Cliente insertado correctamente.");
				try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						cliente.setId(generatedKeys.getInt(1));
					} else {
						System.out.println("No se pudo obtener el ID del cliente insertado.");
					}
				}
			} else {
				System.out.println("Error al insertar el cliente.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para leer un cliente por ID
	public cliente getClienteById(int id) {
		String sql = "SELECT * FROM clientes WHERE id_cliente = ?";
		cliente cliente = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				cliente = new cliente(rs.getInt("id_cliente"), rs.getString("nombre"));
			} else {
				System.out.println("No se encontró el cliente con ID: " + id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cliente;
	}

}
