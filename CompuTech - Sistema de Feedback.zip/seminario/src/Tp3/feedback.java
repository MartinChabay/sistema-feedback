package Tp3;

//Clase que representa un informe de feedback
public class feedback {
 private static int contador = 0;
 private int id;
 private String producto;
 private String nombreCliente;
 private int atencionCliente;
 private int calidadMateriales;
 private int funcionamiento;
 private double promedio;
 private respuesta respuesta;

 // Constructor que inicializa los atributos del feedback
 public feedback(String producto, String nombreCliente, int atencionCliente, int calidadMateriales, int funcionamiento, double promedio) {
     this.id = ++contador;
     this.producto = producto;
     this.nombreCliente = nombreCliente;
     this.atencionCliente = atencionCliente;
     this.calidadMateriales = calidadMateriales;
     this.funcionamiento = funcionamiento;
     this.promedio = promedio;
 }

 // Método para obtener el ID del feedback
 public int getId() {
     return id;
 }

 // Método para obtener el nombre del cliente
 public String getNombreCliente() {
     return nombreCliente;
 }

 // Método para obtener el promedio
 public double getPromedio() {
     return promedio;
 }

 // Método para establecer la respuesta del feedback
 public void setRespuesta(respuesta respuesta) {
     this.respuesta = respuesta;
 }

 // Método para obtener la respuesta del feedback
 public respuesta getRespuesta() {
     return respuesta;
 }

 // Método para mostrar los detalles del feedback
 public String mostrar() {
     return "Nombre del Cliente: " + nombreCliente + "\nID: " + id + "\nProducto: " + producto +
            "\nAtención al Cliente: " + atencionCliente + "\nCalidad de Materiales: " + calidadMateriales +
            "\nFuncionamiento: " + funcionamiento + "\nPromedio en Estrellas: " + promedio +
            (respuesta != null ? "\nRespuesta: " + respuesta.getTexto() : "");
 }

 // Método para mostrar los detalles del feedback con la respuesta del empleado
 public String mostrarConRespuesta(String nombreEmpleado) {
     return "Nombre del Cliente: " + nombreCliente + "\nID: " + id + "\nProducto: " + producto +
            "\nAtención al Cliente: " + atencionCliente + "\nCalidad de Materiales: " + calidadMateriales +
            "\nFuncionamiento: " + funcionamiento + "\nPromedio: " + promedio +
            (respuesta != null ? "\nRespuesta: " + respuesta.getTexto() + "\nRespondido por: " + nombreEmpleado : "");
 }
}