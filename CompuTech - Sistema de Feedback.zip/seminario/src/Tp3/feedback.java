package Tp3;

// Clase feddback 
public class feedback {
	private int id;
	private int clienteId;
	private int productoId;
	private int atencionCliente;
	private int calidadMateriales;
	private int funcionamiento;
	private double promedio;
	private String comentario;
	private respuesta respuesta;

	// Constructor con ID
	public feedback(int id, int clienteId, int productoId, int atencionCliente, int calidadMateriales,
			int funcionamiento, double promedio, String comentario) {
		this.id = id;
		this.clienteId = clienteId;
		this.productoId = productoId;
		this.atencionCliente = atencionCliente;
		this.calidadMateriales = calidadMateriales;
		this.funcionamiento = funcionamiento;
		this.promedio = promedio;
		this.comentario = comentario;
	}

	// Constructor sin ID
	public feedback(int clienteId, int productoId, int atencionCliente, int calidadMateriales, int funcionamiento,
			double promedio, String comentario) {
		this.clienteId = clienteId;
		this.productoId = productoId;
		this.atencionCliente = atencionCliente;
		this.calidadMateriales = calidadMateriales;
		this.funcionamiento = funcionamiento;
		this.promedio = promedio;
		this.comentario = comentario;
	}

	// Getters y Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getClienteId() {
		return clienteId;
	}

	public void setClienteId(int clienteId) {
		this.clienteId = clienteId;
	}

	public int getProductoId() {
		return productoId;
	}

	public void setProductoId(int productoId) {
		this.productoId = productoId;
	}

	public int getAtencionCliente() {
		return atencionCliente;
	}

	public void setAtencionCliente(int atencionCliente) {
		this.atencionCliente = atencionCliente;
	}

	public int getCalidadMateriales() {
		return calidadMateriales;
	}

	public void setCalidadMateriales(int calidadMateriales) {
		this.calidadMateriales = calidadMateriales;
	}

	public int getFuncionamiento() {
		return funcionamiento;
	}

	public void setFuncionamiento(int funcionamiento) {
		this.funcionamiento = funcionamiento;
	}

	public double getPromedio() {
		return promedio;
	}

	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public respuesta getRespuesta() {
		return respuesta;
	}

	public void setRespuesta(respuesta respuesta) {
		this.respuesta = respuesta;
	}

	// Método para mostrar la información del feedback
	public String mostrar() {
		StringBuilder sb = new StringBuilder();
		sb.append("ID del Feedback: ").append(id).append("\n");
		sb.append("Cliente ID: ").append(clienteId).append("\n");
		sb.append("Producto ID: ").append(productoId).append("\n");
		sb.append("Atención al Cliente: ").append(atencionCliente).append("\n");
		sb.append("Calidad de los Materiales: ").append(calidadMateriales).append("\n");
		sb.append("Funcionamiento: ").append(funcionamiento).append("\n");
		sb.append("Promedio: ").append(promedio).append("\n");
		sb.append("Comentario: ").append(comentario).append("\n");
		if (respuesta != null) {
			sb.append("Respuesta: ").append(respuesta.getTexto()).append("\n");
		}
		return sb.toString();
	}
}
