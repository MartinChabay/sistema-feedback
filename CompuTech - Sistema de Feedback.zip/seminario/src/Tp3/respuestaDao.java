package Tp3;
// Clase respuesta asociada con la base de datos 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class respuestaDao {

	// Método para insertar una respuesta
	public void insertRespuesta(respuesta respuesta) {
		String sql = "INSERT INTO respuestas (id_feedback, id_empleado, contenido, fecha_respuesta) VALUES (?, ?, ?, ?)";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			pstmt.setInt(1, respuesta.getFeedbackId());
			pstmt.setInt(2, respuesta.getEmpleadoId());
			pstmt.setString(3, respuesta.getContenido());
			pstmt.setTimestamp(4, respuesta.getFechaRespuesta());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Respuesta insertada correctamente.");
				try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
					if (generatedKeys.next()) {
						respuesta.setId(generatedKeys.getInt(1));
					} else {
						System.out.println("No se pudo obtener el ID de la respuesta insertada.");
					}
				}
			} else {
				System.out.println("Error al insertar la respuesta.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para leer una respuesta por ID
	public respuesta getRespuestaById(int id) {
		String sql = "SELECT * FROM respuestas WHERE id_respuesta = ?";
		respuesta respuesta = null;

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				respuesta = new respuesta(rs.getInt("id_respuesta"), rs.getInt("id_feedback"), rs.getInt("id_empleado"),
						rs.getString("contenido"), rs.getTimestamp("fecha_respuesta"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return respuesta;
	}

	// Método para actualizar una respuesta
	public void updateRespuesta(respuesta respuesta) {
		String sql = "UPDATE respuestas SET contenido = ?, fecha_respuesta = ? WHERE id_respuesta = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setString(1, respuesta.getContenido());
			pstmt.setTimestamp(2, respuesta.getFechaRespuesta());
			pstmt.setInt(3, respuesta.getId());
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Respuesta actualizada correctamente.");
			} else {
				System.out.println("Error al actualizar la respuesta.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Método para eliminar una respuesta por ID
	public void deleteRespuesta(int id) {
		String sql = "DELETE FROM respuestas WHERE id_respuesta = ?";

		try (Connection conn = databaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {

			pstmt.setInt(1, id);
			int rowsAffected = pstmt.executeUpdate();

			if (rowsAffected > 0) {
				System.out.println("Respuesta eliminada correctamente.");
			} else {
				System.out.println("Error al eliminar la respuesta.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
