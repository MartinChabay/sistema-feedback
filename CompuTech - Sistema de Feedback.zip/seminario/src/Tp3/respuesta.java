package Tp3;

//Clase que representa una respuesta a un informe de feedback
public class respuesta {
 private String texto;

 // Constructor que inicializa el texto de la respuesta
 public respuesta(String texto) {
     this.texto = texto;
 }

 // Método para obtener el texto de la respuesta
 public String getTexto() {
     return texto;
 }
}