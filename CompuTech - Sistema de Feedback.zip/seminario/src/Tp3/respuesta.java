package Tp3;

// Clase respuesta 
import java.sql.Timestamp;

public class respuesta {
	private int id;
	private int feedbackId;
	private int empleadoId;
	private String contenido;
	private Timestamp fechaRespuesta;

	// Método para devolver el texto de la respuesta
	public String getTexto() {
		return contenido;
	}

	// Constructor con ID
	public respuesta(int id, int feedbackId, int empleadoId, String contenido, Timestamp fechaRespuesta) {
		this.id = id;
		this.feedbackId = feedbackId;
		this.empleadoId = empleadoId;
		this.contenido = contenido;
		this.fechaRespuesta = fechaRespuesta;
	}

	// Constructor sin ID para inserción
	public respuesta(int feedbackId, int empleadoId, String contenido, Timestamp fechaRespuesta) {
		this.feedbackId = feedbackId;
		this.empleadoId = empleadoId;
		this.contenido = contenido;
		this.fechaRespuesta = fechaRespuesta;
	}

	// Getters y Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public int getEmpleadoId() {
		return empleadoId;
	}

	public void setEmpleadoId(int empleadoId) {
		this.empleadoId = empleadoId;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public Timestamp getFechaRespuesta() {
		return fechaRespuesta;
	}

	public void setFechaRespuesta(Timestamp fechaRespuesta) {
		this.fechaRespuesta = fechaRespuesta;
	}

}
